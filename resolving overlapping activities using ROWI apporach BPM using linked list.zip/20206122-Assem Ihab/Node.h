#ifndef NODE_H
#define NODE_H

template<class T>
class Node
{
public:
    T info;
    Node* next;
    Node (T value, Node*n=0):info(value),next(n){}
    Node*getNext()
    {
        return next;
    }
    void setNext(Node*n)
    {
        next=n;
    }
    T getInfo()
    {
        return info;
    }
    void setInfo(T value)
    {
        info= value;
    }
};

#endif // NODE_H
