#ifndef SLL_H
#define SLL_H
//#include "Node.h"
#include <iostream>

using namespace std;
template <class T>
class SLL
{
    Node<T>*head,*tail;
public:
    SLL()
    {
        head=tail=0;
    }
    void updateInfo(char t2)
    {
        Node<T>*TraverseNode=head;
        while(TraverseNode->getNext()!=0)
        {

            if(TraverseNode->info.task==t2&&TraverseNode->info.eventType=="started")
            {
                TraverseNode->info.eventType="allocated";
                break;
            }
            TraverseNode=TraverseNode->getNext();
        }
    }
    void addAfter(T obj1,T obj2)
    {
        Node<T>*TraverseNode=head;
        while(!(TraverseNode->info==obj1))
        {
            TraverseNode=TraverseNode->getNext();
        }
        Node<T>*new_node=new Node<T>(obj2,TraverseNode->getNext());
        TraverseNode->setNext(new_node);
    }
    void addToHead(T value)
    {
        Node<T>*new_node=new Node<T>(value,head);
        head=new_node;
        if(tail==0)
            tail=head;
    }
    void addToTail(T value)
    {
        Node<T>*new_node=new Node<T>(value);
        if(tail==0)
            {
                addToHead(value);
                return;
            }
        tail->setNext(new_node);
        tail=tail->getNext();
    }
    T removeFromHead()
    {
        T value=head->getInfo();
        if(head==tail)
        {
            delete head;
            head=tail=0;
            return value;
        }
        Node<T>*ptrToHead=head;
        head=head->getNext();
        delete ptrToHead;
        return value;
    }
    T removeFromTail()
    {
        if(head==tail)
        {
            T value =removeFromHead();
            return value;
        }
        Node<T>*traversePtr=head;
        while(traversePtr->getNext()!=tail)
            {
                traversePtr=traversePtr->getNext();
            }
        T value=tail->getInfo();
        delete tail;
        tail=traversePtr;
        tail->setNext(0);
        return value;
    }
    T getValueAtHead()
    {
        return head->getInfo();
    }
    bool isEmpty()
    {
        return head==0;
    }
    void clear()
    {
        Node<T>*deletingPtr;
        while(head!=0)
        {
            deletingPtr=head;
            head=head->getNext();
            delete deletingPtr;
        }
    }
    void printSLL()
    {
        Node<T>*TraverseNode=head;
        while(TraverseNode!=0)
        {
            T value=TraverseNode->getInfo();
            cout<<value;
            TraverseNode=TraverseNode->getNext();
            cout<<endl;

        }
    }

    template<class T1>
    friend ostream&operator<<(ostream&,const SLL<T1>&);
};

#endif // SLL_H
