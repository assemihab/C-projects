#include <iostream>
#include <stack>
#include <queue>
#include<list>
#include"Node.h"
#include"SLL.h"

using namespace std;
class Records
{
public:
    int Case;
    char task;
    string resource;
    string eventType;
    string timeStamp;
    Records()
    {
        Case=1;
        resource="R1";
        timeStamp="t";
    }
    bool operator ==(Records&obj2)
    {
        if((task==obj2.task)&&(eventType==obj2.eventType))
            return true;
        else
            return false;
    }
friend ostream & operator <<(ostream &, Records &);
friend istream & operator >> (istream &in,  Records &obj);
};

enum patterType{o,di};

class Patterns
{
public:
    char task1;
    patterType pat;
    char task2;
    Patterns()
    {
        task1=' ';
        task2=' ';
        pat=o;
    }
    Patterns(char t1,patterType p,char t2)
    {
        task1=t1;
        pat=p;
        task2=t2;
    }

};

ostream & operator<<(ostream &out, Records &obj)
{

    out<<obj.Case<<"\t"<<obj.task<<"\t"<<obj.resource<<"\t"<<obj.eventType<<"\t"<<obj.timeStamp;
    return out;
}
istream & operator>>(istream &in, Records &obj)
{
    cout<<"\nEnter the values separated by tabs: \n";
    //make input validation for case
    in>>obj.Case>>obj.task>>obj.resource>>obj.eventType>>obj.timeStamp;
    return in;
}
int main()
{

    stack<Patterns>s;
    queue<Patterns>q;
    Patterns*arrOfPatterns;
    int numOfRecords;
    cout<<"Enter the number of records in log you have: ";
    cin>>numOfRecords;
    Records*recArr=new Records[numOfRecords];
    for(int i=0;i<numOfRecords;i++)
    {
        cout<<"\nEnter the values of record "<<i+1;
        cout<<" \nin this order(case,task,resource, eventType,timeStamp): ";
        cin>>recArr[i];
    }
    Records*startedArr,*compArr;
    startedArr=new Records[numOfRecords/2];
    compArr=new Records[numOfRecords/2];
    for(int i=0, j=numOfRecords/2;i<numOfRecords/2,j<numOfRecords;i++,j++)
    {
        startedArr[i]=recArr[i];
        compArr[i]=recArr[j];
    }

    for(int i=0;i<numOfRecords/2;i++)
    {
        if(startedArr[i].task==compArr[i].task)
        {
            for(int j=i+1;j<numOfRecords/2;j++)
            {
                Patterns obj(startedArr[i].task,o,startedArr[j].task);
                s.push(obj);
            }
        }
        else
        {
            for(int j=i+1;j<numOfRecords/2;j++)
            {
                Patterns obj(startedArr[i].task,di,startedArr[j].task);
                q.push(obj);
            }
        }
    }
    SLL<Records>RList;
    for(int i=0;i<numOfRecords;i++)
    {
        RList.addToTail(recArr[i]);
    }
    while(!s.empty())
    {
        Patterns pat=s.top();
        s.pop();
        Records rec1;
        for(int i=0;i<numOfRecords;i++)
        {
            if(recArr[i].task==pat.task1&&recArr[i].eventType=="completed")
                rec1=recArr[i];
        }
        Records rec2;
        rec2.task=pat.task2;
        rec2.eventType="started";
        RList.addAfter(rec1,rec2);
        RList.updateInfo(pat.task2);
    }

    while(!q.empty())
    {
        Patterns pat=q.front();
        q.pop();
        Records rec1;
        rec1.task=pat.task1;
        rec1.eventType="started";
        Records rec2;
        rec2.task=pat.task1;
        rec2.eventType="suspended";
        RList.addAfter(rec1,rec2);
        Records rec3;
        rec3.task=pat.task2;
        rec3.eventType="completed";
        RList.addAfter(rec3,rec1);
    }
    RList.printSLL();


    return 0;
}
