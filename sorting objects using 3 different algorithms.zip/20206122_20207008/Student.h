#ifndef STUDENT_H
#define STUDENT_H

using namespace std;

class Student
{
private:
    string name;
    string id;
    double gpa;

public:
    Student(string Name="",string ID="", double GPA=0)
    {
        name=Name;
        id=ID;
        gpa=GPA;
    }
    void print()
    {
        cout<<"Student's name is: "<<name<<endl;
        cout<<"Student's ID is: "<<id<<endl;
        cout<<"Student's GPA is: "<<gpa<<endl;
    }
    bool operator<(const Student& obj)
    {
        if(name<obj.name)
            return true;
        else
            return false;
    }
    string getName()const
    {
        return name;
    }
    template <class T>
    friend void printOnFile(ofstream&oFile,T**,int,int);
};

#endif
