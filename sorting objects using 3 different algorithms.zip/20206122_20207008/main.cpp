#include <iostream>
#include <fstream>
#include <cmath>
#include "Student.h"

using namespace std;

template <class T>
int bubbleSorting(T**, int);
template <class T>
int shellSorting(T**,int );
template <class T>
void mergeSorting(T**,int ,int );
template <class T>
void Merge(T**,int ,int ,int );
template <class T>
void printArray(T**,int ,int );
template <class T>
void binarySearch(T**,int ,int ,string );
template <class T>
void printOnFile(ofstream&,T**,int,int);

int globCounter;

int main()
{
    string wantedName;
    Student**a1,**a2,**a3;
    string Name,Id;
    double gPa;
    int Size;

    ofstream bubbleFile("bubblesort.txt");
    ofstream shellFile("shellsort.txt");
    ofstream mergeFile("merge.txt");
    ifstream ifile("student.txt");

    ifile>>Size;

    a1=new Student*[Size];
    a2=new Student*[Size];
    a3=new Student*[Size];

    for(int i=0;i<Size;i++)
    {
        ifile.ignore();
        getline(ifile,Name);
        ifile>>Id>>gPa;
        a1[i]=new Student(Name,Id,gPa);
        a2[i]=new Student(Name,Id,gPa);
        a3[i]=new Student(Name,Id,gPa);
    }

    int counter=bubbleSorting(a1,Size);
    int counter2=shellSorting(a2,Size);
    mergeSorting(a3,0,Size-1);

    printOnFile(bubbleFile,a1,Size,counter);
    printOnFile(shellFile,a2,Size,counter2);
    printOnFile(mergeFile,a3,Size,globCounter);

    char choice;
    do
    {
        cout<<"\n1- Show number of comparisons and sorted array of selection sort";
        cout<<"\n2- Show number of comparisons and sorted array of shell sort";
        cout<<"\n3- Show number of comparisons and sorted array of merge sort";
        cout<<"\n4- Search for a student by name";
        cout<<"\n5- Exit";
        cout<<"\nyour choice: ";
invalidChoice:
        cin>>choice;
        switch(choice)
        {
            case '1':printArray(a1,Size,counter);
            break;
            case '2':printArray(a2,Size,counter2);
            break;
            case '3':printArray(a3,Size,globCounter);
            break;
            case '4':binarySearch(a1,0,Size-1,wantedName);
            break;
            case '5':cout<<"\nExitingggggggggg";exit(0);
            default:cout<<"\nreEnter your choice: ";goto invalidChoice;
            break;
        }
    }
    while(choice!='5');

    ifile.close();

    bubbleFile.close();
    shellFile.close();
    mergeFile.close();

    for(int i=0;i<Size;i++)
    {
        delete a1[i];
        delete a2[i];
        delete a3[i];
    }
    delete[]a1;
    delete[]a2;
    delete[]a3;
    return 0;
}

template<class T>
//revise on the pointer here
int bubbleSorting(T**arr, int n)
{
    int counter;
    for(int i=0;i<n-1;i++)
    {
        for(int j=1;j<n-i;j++)
        {
            counter++;
            T tmp=*(arr[j-1]);
            if(*(arr[j])<*(arr[j-1]))
            {
                *(arr[j-1])=*(arr[j]);
                *(arr[j])=tmp;
            }
        }
    }
    return counter;
}
template<class T>
int shellSorting(T**arr,int n)
{
    int counter;
    int j;
    for(int inc=pow(2,(int)(log(n)/log(2)))-1;inc>0;inc/=2)
    {
        for(int i=inc;i<n;i++)
        {
            T tmp=*(arr[i]);
            for(j=i;j>=inc;j-=inc)
            {
                counter++;
                if(tmp<*(arr[j-inc]))
                {
                    *(arr[j])=*(arr[j-inc]);
                }
                else
                    break;
            }
            *(arr[j])=tmp;
        }
    }
    return counter;
}
template<class T>
void mergeSorting(T**arr,int L,int R)
{
    if(L<R)
    {
        int M=(L+R)/2;
        mergeSorting(arr,L,M);
        mergeSorting(arr,M+1,R);
        Merge(arr,L,M,R);
    }
}

template<class T>
void Merge(T**arr,int L,int M,int R)
{
    int I=L;
    int J=M+1;
    int K=L;
    T tmp[R+1];
    while(I<=M&&J<=R)
    {
        globCounter++;
        if(*(arr[I])<*(arr[J]))
        {
            tmp[K]=*(arr[I]);
            I++;
            K++;
        }
        else
        {
            tmp[K]=*(arr[J]);
            J++;
            K++;
        }
    }
    while(I<=M)
    {
        tmp[K]=*(arr[I]);
        I++;
        K++;
    }
    while(J<=R)
    {
        tmp[K]=*(arr[J]);
        J++;
        K++;
    }
    for(int S=L;S<R+1;S++)
    {
        *(arr[S])=tmp[S];
    }
}
template <class T>
void binarySearch(T**arr,int left,int right,string value)
{

    cout<<"\nEnter the name: ";
    cin.ignore();
    getline(cin,value);

    while(left<=right)
    {
        int middle=left+(right-left)/2;
        if(arr[middle]->getName()==value)
        {
            arr[middle]->print();
            return;
        }
        if(arr[middle]->getName()<value)
            left=middle+1;
        else
            right=middle-1;
    }
    cout<<"\nThe name is not found.";
    return;
}
template <class T>
void printArray(T**arr,int n,int comparisons)
{
    cout<<"\nNumber of comparisons = "<<comparisons<<endl;
    for(int i=0;i<n;i++)
    {
        arr[i]->print();
    }
}
template <class T>
void printOnFile(ofstream& oFile,T**arr,int n,int Counter)
{
    oFile<<"Number of comparisons = "<<Counter<<endl;
    for(int i=0;i<n;i++)
    {
        oFile<<arr[i]->name<<endl;
        oFile<<arr[i]->id<<endl;
        oFile<<arr[i]->gpa<<endl;
    }
}
